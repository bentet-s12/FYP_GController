# FYP_GController
A gesture based machine learning controller for FYP
